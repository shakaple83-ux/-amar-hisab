আমার ব্যবসার হিসাব - Android project

ফিচার:
- বিক্রি, ক্রয়, খরচ
- পাওনা, দেনা
- পণ্য ও স্টক
- কারিগর/কর্মী ও পেমেন্ট
- রিপোর্ট ও ৭ দিনের চার্ট
- Backup/Restore

পথ ১ — মোবাইল দিয়ে GitHub Actions:
1. GitHub-এ নতুন repository তৈরি করুন।
2. এই ZIP-এর সব ফাইল repository-তে upload করুন (ZIP ফাইলটিকে সরাসরি upload করবেন না; ZIP খুলে ভেতরের files upload করবেন)।
3. Actions > Build Amar Hisab APK > Run workflow চাপুন।
4. কাজ শেষ হলে workflow run খুলে Artifacts থেকে AmarHisab-debug-APK.zip download করুন।
5. ZIP খুলে app-debug.apk ফোনে install করুন।

পথ ২ — Android Studio/AndroidIDE:
Project folder খুলে Gradle sync করুন এবং Build > APK/assembleDebug চালান।
JDK 17 ব্যবহার করুন।
